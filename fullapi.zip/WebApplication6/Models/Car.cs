﻿using System;
using System.Collections.Generic;

namespace WebApplication6.Models;

public partial class Car
{
    public int Id { get; set; }

    public string? Name { get; set; }

    public string? Photo { get; set; }

    public string? Description { get; set; }

    public virtual ICollection<Application> Applications { get; } = new List<Application>();
    public int IdCar { get; internal set; }
}
