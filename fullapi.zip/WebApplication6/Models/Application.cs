﻿using System;
using System.Collections.Generic;

namespace WebApplication6.Models;

public partial class Application
{
    public int Id { get; set; }

    public string? Number { get; set; }

    public string? Name { get; set; }

    public string? Status { get; set; }

    public int IdCar { get; set; }

    public int IdEmployee { get; set; }

    public virtual Car IdCarNavigation { get; set; } = null!;

    public virtual Employee IdEmployeeNavigation { get; set; } = null!;
}
