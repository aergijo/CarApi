﻿using System;
using System.Collections.Generic;

namespace WebApplication6.Models;

public partial class Employee
{
    public int Id { get; set; }

    public string? Name { get; set; }

    public string? Post { get; set; }

    public string? Login { get; set; }

    public string? Password { get; set; }

    public virtual ICollection<Application> Applications { get; } = new List<Application>();
}
