﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication6.Models;

namespace WebApplication6.Controllers
{
    namespace WebApplication6.Controllers
    {
        [ApiController]
        [Route("Employee")]
        public class EmployeeController : ControllerBase
        {
            [HttpGet]
            [Route("all")]

            public IActionResult GetAll()
            {
                var db = new CarContext();
                return Ok(db.Employees);
            }
            [HttpGet]
            [Route("{id}")]

            public IActionResult Get(int id)
            {
                var db = new CarContext();
                var car = db.Applications.FirstOrDefault(x => x.Id == id);
                if (car == null) { return NotFound(); }
                return Ok(car);
            }

            [HttpPost]
            public IActionResult Add(Employee emp)
            {
                var db = new CarContext();
                db.Employees.Add(emp);
                db.SaveChanges();
                return Ok();
            }
            [HttpPut]
            public IActionResult Update(Employee emp)
            {
                var db = new CarContext();
                db.Employees.Update(emp);
                db.SaveChanges();
                return Ok(emp);
            }
            [HttpDelete]
            public IActionResult Delete(int id)
            {
                var db = new CarContext();
                var emp = db.Employees.FirstOrDefault(x => x.Id == id);
                if (emp == null) { return NotFound(); }
                db.Employees.Remove(emp);
                db.SaveChanges();
                return Ok();
            }
            [HttpPost]
            [Route("{auth}")]
            public IActionResult Auth(Employee emp)
            {
                var db = new CarContext();
                List<Employee> emps = new List<Employee>();
                foreach (var emp1 in db.Employees)
                {
                    emps.Add(emp1);
                }
                Employee CurrentUser = emps.FirstOrDefault(n => n.Login == emp.Login && n.Password == emp.Password);
                if (CurrentUser == null) return Forbid();
                return Ok();
            }
        }
    }
}