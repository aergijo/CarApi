﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication6.Models;

namespace WebApplication6.Controllers
{
    namespace WebApplication6.Controllers
    {
        [ApiController]
        [Route("car")]
        public class CarController : ControllerBase
        {
            [HttpGet]
            [Route("all")]

            public IActionResult GetAll()
            {
                var db = new CarContext();
                return Ok(db.Cars);
            }
            [HttpGet]
            [Route("{id}")]

            public IActionResult Get(int id)
            {
                var db = new CarContext();
                var car = db.Cars.FirstOrDefault(x => x.IdCar == id);
                if (car == null) { return NotFound(); }
                return Ok(car);
            }

            [HttpPost]
            public IActionResult Add(Car car)
            {
                var db = new CarContext();
                db.Cars.Add(car);
                db.SaveChanges();
                return Ok();
            }
            [HttpPut]
            public IActionResult Update(Car car)
            {
                var db = new CarContext();
                db.Cars.Update(car);
                db.SaveChanges();
                return Ok(car);
            }
            [HttpDelete]
            public IActionResult Delete(int id)
            {
                var db = new CarContext();
                var car = db.Cars.FirstOrDefault(x => x.IdCar == id);
                if (car == null) { return NotFound(); }
                db.Cars.Remove(car);
                db.SaveChanges();
                return Ok();
            }
        }
    }
}