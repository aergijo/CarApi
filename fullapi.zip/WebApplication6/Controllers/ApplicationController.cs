﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication6.Models;

namespace WebApplication6.Controllers
{
    namespace WebApplication6.Controllers
    {
        [ApiController]
        [Route("application")]
        public class ApplicationController : ControllerBase
        {
            [HttpGet]
            [Route("all")]

            public IActionResult GetAll()
            {
                var db = new CarContext();
                return Ok(db.Applications);
            }
            [HttpGet]
            [Route("{id}")]

            public IActionResult Get(int id)
            {
                var db = new CarContext();
                var car = db.Applications.FirstOrDefault(x => x.Id == id);
                if (car == null) { return NotFound(); }
                return Ok(car);
            }

            [HttpPost]
            public IActionResult Add(Application app)
            {
                var db = new CarContext();
                db.Applications.Add(app);
                db.SaveChanges();
                return Ok();
            }
            [HttpPut]
            public IActionResult Update(Application app)
            {
                var db = new CarContext();
                db.Applications.Update(app);
                db.SaveChanges();
                return Ok(app);
            }
            [HttpDelete]
            public IActionResult Delete(int id)
            {
                var db = new CarContext();
                var app = db.Applications.FirstOrDefault(x => x.Id == id);
                if (app == null) { return NotFound(); }
                db.Applications.Remove(app);
                db.SaveChanges();
                return Ok();
            }
        }
    }
}